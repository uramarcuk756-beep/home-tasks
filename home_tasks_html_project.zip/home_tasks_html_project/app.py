from flask import (
    Flask, request, jsonify, render_template,
    session, redirect
)
import sqlite3
import socket
import time
import json
import os
import hmac
import secrets
from datetime import datetime, timedelta

try:
    from zoneinfo import ZoneInfo
    KYIV_TZ = ZoneInfo("Europe/Kyiv")
except Exception:
    KYIV_TZ = None

app = Flask(__name__)
DB = "tasks.db"

# Адміністратор
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "change-this-password")

# Встанови FLASK_SECRET_KEY у змінних середовища для постійного ключа.
# Якщо змінної немає, ключ генерується автоматично під час запуску.
app.secret_key = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1") == "1",  # HTTPS на хостингу.
    PERMANENT_SESSION_LIFETIME=60 * 60 * 8
)

DB = "tasks.db"

TASKS = [
    ("dishes", "🍽️ Помити посуд", 5),
    ("bed", "🛏️ Заправити ліжко", 5),
    ("clothes", "👕 Скласти одяг", 5),
    ("dust", "🧹 Протерти пил", 10),
    ("room", "🧹 Прибрати кімнату", 15),
    ("trash", "🗑️ Винести сміття", 10),
    ("mom", "❤️ Допомогти мамі", 15),
    ("kitchen", "🍳 Прибрати кухню", 20),
    ("yard", "🌳 Прибрати у дворі", 25),
    ("floor", "🧽 Помити підлогу", 20),
    ("house", "🏠 Прибрати всю хату", 50),
]

PEOPLE = ["Уляна", "Тимоха"]


def connect():
    con = sqlite3.connect(DB, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=15000")
    return con


def init_db():
    with connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS submissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cycle INTEGER,
                person TEXT,
                task_id TEXT,
                task_name TEXT,
                price INTEGER,
                status TEXT,
                created REAL
            )
        """)
        if not con.execute(
            "SELECT value FROM settings WHERE key='start'"
        ).fetchone():
            con.execute(
                "INSERT INTO settings VALUES ('start', ?)",
                (str(time.time()),)
            )
            con.execute(
                "INSERT INTO settings VALUES ('cycle', '1')"
            )


def kyiv_now():
    """Поточний час у часовому поясі Києва."""
    if KYIV_TZ is not None:
        return datetime.now(KYIV_TZ)
    # Резервний варіант: локальний час пристрою, якщо zoneinfo недоступний.
    return datetime.now().astimezone()


def seconds_until_midnight():
    now = kyiv_now()
    tomorrow = (now + timedelta(days=1)).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    return max(0, int((tomorrow - now).total_seconds()))


def ensure_cycle():
    """Новий цикл починається щодня о 00:00 за київським часом."""
    today = kyiv_now().date()

    with connect() as con:
        start_row = con.execute(
            "SELECT value FROM settings WHERE key='start'"
        ).fetchone()
        cycle_row = con.execute(
            "SELECT value FROM settings WHERE key='cycle'"
        ).fetchone()
        date_row = con.execute(
            "SELECT value FROM settings WHERE key='cycle_date'"
        ).fetchone()

        cycle = int(cycle_row["value"])

        # Міграція старої бази: перший запуск нової версії починає
        # відлік щоденних циклів із сьогоднішньої дати.
        if date_row is None:
            con.execute(
                "INSERT INTO settings (key, value) VALUES ('cycle_date', ?)",
                (today.isoformat(),)
            )
        else:
            saved_date = datetime.strptime(
                date_row["value"], "%Y-%m-%d"
            ).date()

            if today > saved_date:
                days_passed = (today - saved_date).days
                cycle += days_passed

                con.execute(
                    "UPDATE settings SET value=? WHERE key='cycle'",
                    (str(cycle),)
                )
                con.execute(
                    "UPDATE settings SET value=? WHERE key='cycle_date'",
                    (today.isoformat(),)
                )
                con.execute("""
                    UPDATE submissions
                    SET status='expired'
                    WHERE status='pending' AND cycle < ?
                """, (cycle,))

                print("\\n🔄 НОВИЙ ДЕННИЙ ЦИКЛ! Завдання оновлено.")

        # Зберігаємо start для сумісності з наявною базою.
        start = time.time()
        con.execute(
            "UPDATE settings SET value=? WHERE key='start'",
            (str(start),)
        )

    return cycle, start


def latest_states(con, cycle, person):
    rows = con.execute("""
        SELECT task_id, status
        FROM submissions
        WHERE cycle=? AND person=?
        ORDER BY id DESC
    """, (cycle, person)).fetchall()

    result = {}
    for row in rows:
        if row["task_id"] not in result:
            result[row["task_id"]] = row["status"]
    return result


def admin_required():
    return bool(session.get("admin") is True)


def make_csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


def valid_csrf():
    sent = request.headers.get("X-CSRF-Token", "")
    expected = session.get("csrf_token", "")
    return bool(expected) and hmac.compare_digest(sent, expected)


@app.route("/")
def home():
    task_json = json.dumps(
        [{"id": i, "name": n, "price": p} for i, n, p in TASKS],
        ensure_ascii=False
    )
    return render_template("index.html", tasks_json=task_json)


@app.route("/api/state")
def api_state():
    person = request.args.get("person", "")
    if person not in PEOPLE:
        return jsonify({"error": "Невідомий профіль"}), 400

    cycle, start = ensure_cycle()

    with connect() as con:
        states = latest_states(con, cycle, person)
        earned = con.execute("""
            SELECT COALESCE(SUM(price),0)
            FROM submissions
            WHERE cycle=? AND person=? AND status='approved'
        """, (cycle, person)).fetchone()[0]

        waiting = con.execute("""
            SELECT COUNT(*) FROM (
                SELECT task_id, status,
                ROW_NUMBER() OVER (
                    PARTITION BY task_id ORDER BY id DESC
                ) AS rn
                FROM submissions
                WHERE cycle=? AND person=?
            )
            WHERE rn=1 AND status='pending'
        """, (cycle, person)).fetchone()[0]

    return jsonify({
        "states": states,
        "earned": earned,
        "waiting": waiting,
        "cycle": cycle,
        "next_reset": seconds_until_midnight()
    })


@app.route("/api/submit", methods=["POST"])
def api_submit():
    data = request.get_json(silent=True) or {}
    person = data.get("person")
    ids = data.get("tasks", [])

    if person not in PEOPLE or not isinstance(ids, list):
        return jsonify({"error": "Невірні дані"}), 400
    if len(ids) > len(TASKS) or not all(isinstance(x, str) for x in ids):
        return jsonify({"error": "Невірний список завдань"}), 400

    cycle, _ = ensure_cycle()
    added = 0

    with connect() as con:
        states = latest_states(con, cycle, person)

        for task_id in set(ids):
            task = next((t for t in TASKS if t[0] == task_id), None)
            if not task or states.get(task_id) in ("pending", "approved"):
                continue

            _, name, price = task
            con.execute("""
                INSERT INTO submissions
                (cycle,person,task_id,task_name,price,status,created)
                VALUES (?,?,?,?,?,'pending',?)
            """, (cycle, person, task_id, name, price, time.time()))

            # Оновлюємо стани, щоб повторний ID у запиті не створив дублікат.
            states[task_id] = "pending"
            added += 1

    return jsonify({"ok": True, "added": added})


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if admin_required():
        return redirect("/admin")

    error = ""
    if request.method == "POST":
        password = request.form.get("password", "")
        if hmac.compare_digest(password, ADMIN_PASSWORD):
            session.clear()
            session["admin"] = True
            session.permanent = True
            make_csrf_token()
            return redirect("/admin")
        error = "❌ Неправильний пароль!"

    return render_template("login.html", error=error)


@app.route("/admin")
def admin_panel():
    if not admin_required():
        return redirect("/admin/login")
    return render_template("admin.html", csrf_token=make_csrf_token())


@app.route("/admin/api")
def admin_api():
    if not admin_required():
        return jsonify({"error": "Немає доступу"}), 401

    with connect() as con:
        rows = con.execute("""
            SELECT id, person, task_name, price
            FROM submissions
            WHERE status='pending'
            ORDER BY id ASC
        """).fetchall()

    return jsonify({"tasks": [dict(row) for row in rows]})


@app.route("/admin/action", methods=["POST"])
def admin_action():
    if not admin_required():
        return jsonify({"error": "Немає доступу"}), 401
    if not valid_csrf():
        return jsonify({"error": "Перевірка безпеки не пройдена"}), 403

    data = request.get_json(silent=True) or {}
    try:
        submission_id = int(data.get("id"))
    except (ValueError, TypeError):
        return jsonify({"error": "Невірний ID"}), 400

    action = data.get("action")
    if action not in ("approve", "reject"):
        return jsonify({"error": "Невірна дія"}), 400

    status = "approved" if action == "approve" else "rejected"

    with connect() as con:
        cur = con.execute("""
            UPDATE submissions
            SET status=?
            WHERE id=? AND status='pending'
        """, (status, submission_id))

        if cur.rowcount == 0:
            return jsonify({
                "error": "Завдання вже перевірено або не існує"
            }), 409

    message = (
        "✓ Завдання зараховано!"
        if status == "approved"
        else "✕ Завдання відхилено!"
    )
    return jsonify({"ok": True, "message": message})


@app.route("/admin/logout", methods=["POST"])
def admin_logout():
    if not admin_required():
        return jsonify({"error": "Немає доступу"}), 401
    if not valid_csrf():
        return jsonify({"error": "Перевірка безпеки не пройдена"}), 403

    session.clear()
    return jsonify({"ok": True})


def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "IP не знайдено"
    finally:
        s.close()


init_db()

if __name__ == "__main__":
    init_db()
    cycle, _ = ensure_cycle()

    print("\n🌐 HOME TASKS SERVER")
    print("Цикл:", cycle)
    print("Сайт: http://" + get_ip() + ":5000")
    print("Адмін-панель: http://" + get_ip() + ":5000/admin/login")
    print("Не закривай Pydroid 3!")

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=False,
        threaded=True,
        use_reloader=False
    )
